DATASETS



RESIDE

Paper:https://ieeexplore.ieee.org/abstract/document/8451944

Download Link:https://sites.google.com/view/reside-dehaze-datasets



I-HAZE

Paper: https://link.springer.com/chapter/10.1007/978-3-030-01449-0\_52

Download Link:https://data.vision.ee.ethz.ch/cvl/ntire18//i-haze/



O-HAZE

Paper: https://ieeexplore.ieee.org/document/8575270

Download Link:https://data.vision.ee.ethz.ch/cvl/ntire18//o-haze/





NH-HAZE:

Paper: https://openaccess.thecvf.com/content\_CVPRW\_2020/html/w31/Ancuti\_NH-HAZE\_An\_Image\_Dehazing\_Benchmark\_With\_Non-Homogeneous\_Hazy\_and\_Haze-Free\_CVPRW\_2020\_paper.

Download Link: https://data.vision.ee.ethz.ch/cvl/ntire20/nh-haze/tml





D-HAZE:

Paper:https://ieeexplore.ieee.org/document/8803046

Download Link:https://data.vision.ee.ethz.ch/cvl/ntire19//dense-haze/

